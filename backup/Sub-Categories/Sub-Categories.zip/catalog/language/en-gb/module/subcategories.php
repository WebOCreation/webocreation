<?php
// Heading
$_['heading_title'] = 'Sub Categories';