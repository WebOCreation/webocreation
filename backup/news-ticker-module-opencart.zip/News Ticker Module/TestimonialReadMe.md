"# testimonial" 

Feedback Module for Opencart for Free -eCommerce Solution

Feedback or Testimonial Module is the module for Opencart by which customer can provide their feedback about the site or product or any services. I was encouraged to develop it because there is only review system for the products but not for the site and services so i made this feedback or testimonial module.

<a href="https://webocreation.com/blog/feedback-module-for-opencart-for-free-ecommerce-solution">Click for Installation steps and Demo</a>
