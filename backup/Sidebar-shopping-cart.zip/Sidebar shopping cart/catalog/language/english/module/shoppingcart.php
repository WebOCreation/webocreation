<?php
// Heading
$_['heading_title'] = 'Shopping Cart';
