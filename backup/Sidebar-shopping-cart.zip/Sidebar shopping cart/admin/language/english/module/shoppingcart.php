<?php
// Heading
$_['heading_title']    = 'Shopping Cart';

// Text
$_['text_module']      = 'Modules';
$_['text_success']     = 'Success: You have modified shopping cart module!';
$_['text_edit']        = 'Edit Shopping Cart Module';

// Entry
$_['entry_status']     = 'Status';

// Error
$_['error_permission'] = 'Warning: You do not have permission to modify shopping cart module!';
